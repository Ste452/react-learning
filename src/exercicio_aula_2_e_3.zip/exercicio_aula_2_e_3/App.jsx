import Pai from './Components_exercicio/Pai';
import RelogioDigital from './Components_exercicio/exercicioRelogioDigital';
import './App.css'

function App() {
  return (
    <div>
      <RelogioDigital />
      <Pai />
    </div>
  );
}

export default App;
